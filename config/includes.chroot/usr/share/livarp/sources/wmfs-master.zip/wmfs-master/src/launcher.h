/*
 *  wmfs2 by Martin Duquesnoy <xorg62@gmail.com> { for(i = 2011; i < 2111; ++i) ©(i); }
 *  For license, see COPYING.
 */

#ifndef LAUNCHER_H
#define LAUNCHER_H

#include "wmfs.h"

void uicb_launcher(Uicb cmd);

#endif /* LAUNCHER_H */
